"""
github_loader.py
----------------
Connects to a GitHub repo via a Personal Access Token and retrieves
all .py files recursively. Fully decoupled from UI — call from any frontend.
"""

from github import Github, GithubException
from dataclasses import dataclass
from typing import Optional
import logging

logger = logging.getLogger(__name__)


@dataclass
class RepoFile:
    path: str          # e.g. "pipelines/ingest_customers.py"
    name: str          # e.g. "ingest_customers.py"
    content: str       # raw source code
    sha: str           # git blob SHA (useful for cache invalidation)
    html_url: str      # link back to GitHub UI


class GitHubLoader:
    """
    Walks a GitHub repository and returns all Python source files.

    Usage:
        loader = GitHubLoader(token="ghp_...", repo="org/data-pipelines")
        files  = loader.get_python_files(branch="main", subfolder="etl/")
    """

    def __init__(self, token: str, repo_name: str):
        self._gh = Github(token)
        try:
            self._repo = self._gh.get_repo(repo_name)
        except GithubException as e:
            raise ValueError(
                f"Cannot access repo '{repo_name}'. "
                f"Check your PAT and repo name. Detail: {e.data.get('message', e)}"
            )

    @property
    def repo_full_name(self) -> str:
        return self._repo.full_name

    @property
    def default_branch(self) -> str:
        return self._repo.default_branch

    def list_branches(self) -> list[str]:
        return [b.name for b in self._repo.get_branches()]

    def get_python_files(
        self,
        branch: Optional[str] = None,
        subfolder: str = "",
        max_files: int = 500,
    ) -> list[RepoFile]:
        """
        Returns all .py files under `subfolder` on the given branch.
        Files larger than 1 MB are skipped (GitHub API limit for inline content).
        """
        branch = branch or self.default_branch
        results: list[RepoFile] = []

        try:
            contents = self._repo.get_contents(subfolder.rstrip("/"), ref=branch)
        except GithubException as e:
            raise ValueError(f"Cannot read path '{subfolder}': {e.data.get('message', e)}")

        # BFS walk
        queue = list(contents) if isinstance(contents, list) else [contents]
        seen: set[str] = set()

        while queue and len(results) < max_files:
            item = queue.pop(0)
            if item.path in seen:
                continue
            seen.add(item.path)

            if item.type == "dir":
                try:
                    children = self._repo.get_contents(item.path, ref=branch)
                    queue.extend(children if isinstance(children, list) else [children])
                except GithubException:
                    logger.warning("Skipping unreadable dir: %s", item.path)

            elif item.type == "file" and item.name.endswith(".py"):
                if item.size > 1_000_000:
                    logger.warning("Skipping large file (>1MB): %s", item.path)
                    continue
                try:
                    raw = item.decoded_content.decode("utf-8", errors="replace")
                    results.append(
                        RepoFile(
                            path=item.path,
                            name=item.name,
                            content=raw,
                            sha=item.sha,
                            html_url=item.html_url,
                        )
                    )
                except Exception as exc:
                    logger.warning("Could not decode %s: %s", item.path, exc)

        logger.info("Loaded %d Python files from %s@%s", len(results), self._repo.full_name, branch)
        return results
