"""
parser.py
---------
Extracts PySpark data lineage from Python source files.

Strategy (layered, most-precise first):
  1. AST walk  — catches structured .select(), .withColumn(), .read.*(), .write.jdbc()
  2. Regex      — fallback for dynamic patterns, string-based column lists, comments

Supports source types: CSV, Excel/XLS, JSON, Parquet, JDBC/DB, email attachment hints.
Target is always Postgres via .write.jdbc() or .insertInto().
"""

import ast
import re
from dataclasses import dataclass, field
from typing import Optional
import logging

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class ColumnMapping:
    source_col: str
    target_col: str
    transform: Optional[str] = None   # e.g. "upper()", "to_date('yyyy-MM-dd')", "cast(IntegerType)"
    source_type: Optional[str] = None
    target_type: Optional[str] = None
    dropped: bool = False             # True if column is read but never written


@dataclass
class SourceInfo:
    kind: str          # "csv" | "excel" | "json" | "parquet" | "jdbc" | "email" | "unknown"
    path: Optional[str] = None        # file path or table name
    options: dict = field(default_factory=dict)


@dataclass
class TargetInfo:
    table: str                        # Postgres table name (schema.table if present)
    url: Optional[str] = None
    mode: Optional[str] = None        # "overwrite" | "append" | "upsert"


@dataclass
class PipelineMapping:
    file_path: str                    # path of the .py file in the repo
    sources: list[SourceInfo] = field(default_factory=list)
    targets: list[TargetInfo] = field(default_factory=list)
    columns: list[ColumnMapping] = field(default_factory=list)
    raw_select_exprs: list[str] = field(default_factory=list)   # unparsed expressions
    warnings: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# Common PySpark type-cast functions → short labels
_CAST_MAP = {
    "IntegerType": "int",
    "LongType": "bigint",
    "DoubleType": "double",
    "FloatType": "float",
    "StringType": "string",
    "BooleanType": "boolean",
    "DateType": "date",
    "TimestampType": "timestamp",
    "DecimalType": "decimal",
}

_SOURCE_KIND_MAP = {
    "csv": "csv",
    "text": "csv",
    "json": "json",
    "parquet": "parquet",
    "orc": "orc",
    "excel": "excel",
    "jdbc": "jdbc",
}

# Regex patterns (used as fallback)
_RE_READ_CSV    = re.compile(r'spark\.read\s*(?:\.[^(]+)?\s*\.csv\s*\(\s*["\']([^"\']+)["\']', re.S)
_RE_READ_EXCEL  = re.compile(r'spark\.read\s*(?:\.[^(]+)?\s*\.format\s*\(\s*["\'](?:excel|com\.crealytics)["\'].*?\.load\s*\(\s*["\']([^"\']+)["\']', re.S)
_RE_READ_JSON   = re.compile(r'spark\.read\s*(?:\.[^(]+)?\s*\.json\s*\(\s*["\']([^"\']+)["\']', re.S)
_RE_READ_PARQ   = re.compile(r'spark\.read\s*(?:\.[^(]+)?\s*\.parquet\s*\(\s*["\']([^"\']+)["\']', re.S)
_RE_JDBC_URL    = re.compile(r'\.jdbc\s*\(\s*["\']([^"\']+)["\']', re.S)
_RE_JDBC_TABLE  = re.compile(r'["\']dbtable["\']:\s*["\']([^"\']+)["\']|\.jdbc\s*\([^,]+,\s*["\']([^"\']+)["\']', re.S)
_RE_WRITE_TABLE = re.compile(r'\.write\b.*?\.(?:jdbc|saveAsTable|insertInto)\s*\(.*?(?:table|dbtable)\s*[=:]\s*["\']([^"\']+)["\']', re.S)
_RE_WITH_COL    = re.compile(r'\.withColumn\s*\(\s*["\']([^"\']+)["\']', re.S)
_RE_DROP_COL    = re.compile(r'\.drop\s*\(\s*["\']([^"\']+)["\']', re.S)
_RE_SELECT_COLS = re.compile(r'\.select\s*\(([^)]{1,800})\)', re.S)
_RE_ALIAS       = re.compile(r'["\']([^"\']+)["\']\s*\)\s*\.alias\s*\(\s*["\']([^"\']+)["\']|col\s*\(\s*["\']([^"\']+)["\']\s*\)\.alias\s*\(\s*["\']([^"\']+)["\']')


# ---------------------------------------------------------------------------
# AST visitor
# ---------------------------------------------------------------------------

class _SparkVisitor(ast.NodeVisitor):
    """Walks an AST and accumulates Spark read/write/transform calls."""

    def __init__(self, file_path: str):
        self.mapping = PipelineMapping(file_path=file_path)
        self._aliases: dict[str, str] = {}        # var_name -> spark var alias
        self._df_vars: set[str] = set()           # variable names holding DataFrames
        self._with_cols: list[tuple[str, str]] = []  # (target_col, transform)
        self._drops: set[str] = set()

    # ---- read detection ----

    def visit_Call(self, node: ast.Call):
        fn = self._fn_name(node)

        # spark.read.csv / json / parquet / text
        if fn in ("csv", "json", "parquet", "text", "orc") and self._is_spark_read(node):
            path = self._first_str_arg(node)
            kind = _SOURCE_KIND_MAP.get(fn, fn)
            self.mapping.sources.append(SourceInfo(kind=kind, path=path))

        # spark.read.format("excel") / format("jdbc")
        elif fn == "format" and self._is_spark_read(node):
            fmt = self._first_str_arg(node)
            if fmt:
                kind = "excel" if "excel" in fmt or "crealytics" in fmt else _SOURCE_KIND_MAP.get(fmt, fmt)
                self.mapping.sources.append(SourceInfo(kind=kind))

        # .load() with jdbc options — try to capture table
        elif fn == "load" and self._is_spark_read(node):
            if self.mapping.sources and self.mapping.sources[-1].kind == "jdbc":
                tbl = self._kwarg_str(node, "dbtable") or self._kwarg_str(node, "query")
                if tbl:
                    self.mapping.sources[-1].path = tbl

        # .option("dbtable", ...) on read side
        elif fn == "option" and self._is_spark_read(node):
            key = self._first_str_arg(node)
            val = self._str_arg(node, 1)
            if key and val:
                if self.mapping.sources:
                    self.mapping.sources[-1].options[key] = val
                    if key == "dbtable":
                        self.mapping.sources[-1].path = val
                        self.mapping.sources[-1].kind = "jdbc"

        # .withColumn("target", expr)
        elif fn == "withColumn":
            target_col = self._str_arg(node, 0)
            transform = self._expr_to_str(node.args[1]) if len(node.args) > 1 else None
            if target_col:
                self.mapping.columns.append(
                    ColumnMapping(
                        source_col=self._infer_source_from_expr(node.args[1]) if len(node.args) > 1 else target_col,
                        target_col=target_col,
                        transform=transform if transform != target_col else None,
                    )
                )

        # .drop("col", ...)
        elif fn == "drop":
            for a in node.args:
                if isinstance(a, ast.Constant) and isinstance(a.value, str):
                    self._drops.add(a.value)

        # .select(...)
        elif fn == "select":
            self._parse_select(node)

        # .write.jdbc(url, table, ...)
        elif fn == "jdbc" and self._is_spark_write(node):
            url   = self._str_arg(node, 0)
            table = self._str_arg(node, 1) or self._kwarg_str(node, "table") or self._kwarg_str(node, "dbtable")
            mode  = self._kwarg_str(node, "mode")
            if table:
                self.mapping.targets.append(TargetInfo(table=table, url=url, mode=mode))

        # .saveAsTable / .insertInto
        elif fn in ("saveAsTable", "insertInto") and self._is_spark_write(node):
            table = self._first_str_arg(node)
            if table:
                self.mapping.targets.append(TargetInfo(table=table))

        # .mode(...)
        elif fn == "mode" and self.mapping.targets:
            m = self._first_str_arg(node)
            if m:
                self.mapping.targets[-1].mode = m

        self.generic_visit(node)

    # ---- select parser ----

    def _parse_select(self, node: ast.Call):
        for arg in node.args:
            # col("x").alias("y")  or  col("x")  or  "x"
            if isinstance(arg, ast.Call):
                alias = self._extract_alias(arg)
                if alias:
                    src, tgt = alias
                    transform = self._expr_to_str(arg)
                    self.mapping.columns.append(ColumnMapping(
                        source_col=src, target_col=tgt,
                        transform=transform if src != tgt else None,
                    ))
                else:
                    # no alias — column keeps its name
                    col_name = self._infer_source_from_expr(arg)
                    if col_name:
                        self.mapping.columns.append(ColumnMapping(source_col=col_name, target_col=col_name))
                    else:
                        self.mapping.raw_select_exprs.append(ast.unparse(arg))
            elif isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                self.mapping.columns.append(ColumnMapping(source_col=arg.value, target_col=arg.value))
            elif isinstance(arg, ast.Starred):
                self.mapping.warnings.append("Dynamic column list (*args) detected — cannot statically resolve")

    # ---- expression helpers ----

    def _extract_alias(self, node: ast.Call) -> Optional[tuple[str, str]]:
        """Returns (source_col, alias) if node is expr.alias('y'), else None."""
        fn = self._fn_name(node)
        if fn == "alias" and node.args:
            tgt = node.args[0].value if isinstance(node.args[0], ast.Constant) else None
            if tgt and isinstance(node.func, ast.Attribute):
                src = self._infer_source_from_expr(node.func.value)
                return (src or "?", tgt)
        return None

    def _infer_source_from_expr(self, node: ast.AST) -> Optional[str]:
        """Best-effort: extract the innermost column name from an expression."""
        if isinstance(node, ast.Constant):
            return str(node.value)
        if isinstance(node, ast.Call):
            fn = self._fn_name(node)
            if fn in ("col", "column") and node.args:
                return node.args[0].value if isinstance(node.args[0], ast.Constant) else None
            # recurse into first arg for cast, upper, lower, etc.
            if node.args:
                return self._infer_source_from_expr(node.args[0])
        if isinstance(node, ast.Attribute):
            return self._infer_source_from_expr(node.value)
        return None

    def _expr_to_str(self, node: ast.AST) -> Optional[str]:
        """Human-readable label for a transformation expression."""
        try:
            return ast.unparse(node)
        except Exception:
            return None

    # ---- chain-detection helpers ----

    def _is_spark_read(self, node: ast.Call) -> bool:
        """True if this call is somewhere in a spark.read.* chain."""
        src = ast.unparse(node.func) if hasattr(node, "func") else ""
        return "read" in src or "spark" in src

    def _is_spark_write(self, node: ast.Call) -> bool:
        src = ast.unparse(node.func) if hasattr(node, "func") else ""
        return "write" in src

    # ---- arg extraction ----

    def _fn_name(self, node: ast.Call) -> str:
        if isinstance(node.func, ast.Attribute):
            return node.func.attr
        if isinstance(node.func, ast.Name):
            return node.func.id
        return ""

    def _first_str_arg(self, node: ast.Call) -> Optional[str]:
        return self._str_arg(node, 0)

    def _str_arg(self, node: ast.Call, idx: int) -> Optional[str]:
        if len(node.args) > idx and isinstance(node.args[idx], ast.Constant):
            return str(node.args[idx].value)
        return None

    def _kwarg_str(self, node: ast.Call, key: str) -> Optional[str]:
        for kw in node.keywords:
            if kw.arg == key and isinstance(kw.value, ast.Constant):
                return str(kw.value.value)
        return None


# ---------------------------------------------------------------------------
# Regex fallback pass
# ---------------------------------------------------------------------------

def _regex_fallback(source: str, mapping: PipelineMapping) -> None:
    """Fill gaps left by the AST pass using regex patterns."""

    # Sources
    if not mapping.sources:
        for m in _RE_READ_CSV.finditer(source):
            mapping.sources.append(SourceInfo(kind="csv", path=m.group(1)))
        for m in _RE_READ_JSON.finditer(source):
            mapping.sources.append(SourceInfo(kind="json", path=m.group(1)))
        for m in _RE_READ_PARQ.finditer(source):
            mapping.sources.append(SourceInfo(kind="parquet", path=m.group(1)))
        for m in _RE_READ_EXCEL.finditer(source):
            mapping.sources.append(SourceInfo(kind="excel", path=m.group(1)))

    # JDBC source detection (format("jdbc").option(...))
    if "jdbc" in source and not any(s.kind == "jdbc" for s in mapping.sources):
        for m in _RE_JDBC_TABLE.finditer(source):
            tbl = m.group(1) or m.group(2)
            if tbl:
                mapping.sources.append(SourceInfo(kind="jdbc", path=tbl))

    # Targets
    if not mapping.targets:
        for m in _RE_WRITE_TABLE.finditer(source):
            mapping.targets.append(TargetInfo(table=m.group(1)))

    # withColumn hints from source text
    if not mapping.columns:
        for m in _RE_WITH_COL.finditer(source):
            col = m.group(1)
            mapping.columns.append(ColumnMapping(source_col=col, target_col=col))

    # Alias pairs from .select()
    for m in _RE_ALIAS.finditer(source):
        src = m.group(1) or m.group(3)
        tgt = m.group(2) or m.group(4)
        if src and tgt:
            # avoid duplicates already captured by AST
            existing = {(c.source_col, c.target_col) for c in mapping.columns}
            if (src, tgt) not in existing:
                mapping.columns.append(ColumnMapping(source_col=src, target_col=tgt))

    # Email hint: if file imports email/imap libraries
    if re.search(r"\b(imaplib|email\.parser|exchangelib|O365)\b", source):
        if not any(s.kind == "email" for s in mapping.sources):
            mapping.sources.append(SourceInfo(kind="email"))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def parse_file(file_path: str, source_code: str) -> PipelineMapping:
    """
    Parse a single PySpark .py file and return its PipelineMapping.

    Args:
        file_path:   path string used for identification (e.g. repo-relative path)
        source_code: raw Python source text

    Returns:
        PipelineMapping with sources, targets, and column mappings populated
        as completely as static analysis allows.
    """
    mapping = PipelineMapping(file_path=file_path)

    # Skip files with no Spark indicators at all (utils, config, tests, etc.)
    if not _looks_like_pipeline(source_code):
        return mapping

    # AST pass
    try:
        tree = ast.parse(source_code)
        visitor = _SparkVisitor(file_path)
        visitor.visit(tree)
        mapping = visitor.mapping
    except SyntaxError as e:
        mapping.warnings.append(f"AST parse error: {e}")

    # Regex fallback
    _regex_fallback(source_code, mapping)

    # Mark dropped columns
    dropped = set()
    try:
        tree = ast.parse(source_code)
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                fn = node.func.attr if isinstance(node.func, ast.Attribute) else ""
                if fn == "drop":
                    for a in node.args:
                        if isinstance(a, ast.Constant):
                            dropped.add(str(a.value))
    except Exception:
        pass

    for col in mapping.columns:
        if col.source_col in dropped:
            col.dropped = True

    # De-duplicate columns (AST + regex may overlap)
    seen: set[tuple] = set()
    deduped: list[ColumnMapping] = []
    for c in mapping.columns:
        key = (c.source_col, c.target_col)
        if key not in seen:
            seen.add(key)
            deduped.append(c)
    mapping.columns = deduped

    return mapping


def _looks_like_pipeline(source: str) -> bool:
    """Quick check: does this file likely contain Spark pipeline code?"""
    spark_indicators = [
        "SparkSession", "spark.read", "DataFrame",
        "pyspark", ".write.", "withColumn", ".select(",
        "SparkContext", "SQLContext",
    ]
    return any(ind in source for ind in spark_indicators)


def parse_files(files: list) -> list[PipelineMapping]:
    """
    Parse a list of RepoFile objects (from github_loader).
    Returns only files that produced at least one source or target.
    """
    results = []
    for f in files:
        mapping = parse_file(f.path, f.content)
        if mapping.sources or mapping.targets or mapping.columns:
            results.append(mapping)
        else:
            logger.debug("No pipeline content found in %s — skipping", f.path)
    logger.info("Parsed %d pipeline files", len(results))
    return results
