"""
app.py
------
Streamlit UI for the PySpark Lineage Explorer.

Run with:
    streamlit run app.py

All business logic lives in github_loader.py / parser.py / lineage.py.
To port to Dash: replace this file only — everything else stays the same.
"""

import streamlit as st
import graphviz
import pandas as pd
import sys
import os

# Make sure our modules are importable
sys.path.insert(0, os.path.dirname(__file__))

from github_loader import GitHubLoader
from parser import parse_files
from lineage import LineageGraph

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------

st.set_page_config(
    page_title="PySpark Lineage Explorer",
    page_icon="🔗",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Session state helpers
# ---------------------------------------------------------------------------

def _init_state():
    defaults = {
        "graph": None,
        "loader": None,
        "branches": [],
        "files_loaded": 0,
        "repo_name": "",
        "error": None,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_state()


# ---------------------------------------------------------------------------
# Sidebar — connection & controls
# ---------------------------------------------------------------------------

with st.sidebar:
    st.title("🔗 Lineage Explorer")
    st.caption("PySpark → Postgres column lineage, straight from GitHub.")
    st.divider()

    st.subheader("GitHub connection")

    token = st.text_input(
        "Personal Access Token",
        type="password",
        placeholder="ghp_...",
        help="Needs `repo` read scope. Token is never stored.",
    )

    repo = st.text_input(
        "Repository",
        placeholder="org/repo-name",
        help="Full name, e.g. myorg/data-pipelines",
    )

    # Load branches once repo + token provided
    if token and repo and repo != st.session_state.repo_name:
        try:
            loader = GitHubLoader(token=token, repo_name=repo)
            st.session_state.branches = loader.list_branches()
            st.session_state.loader = loader
            st.session_state.repo_name = repo
            st.session_state.error = None
        except ValueError as e:
            st.session_state.error = str(e)
            st.session_state.branches = []

    if st.session_state.error:
        st.error(st.session_state.error)

    branch = st.selectbox(
        "Branch",
        options=st.session_state.branches or ["main"],
        disabled=not st.session_state.branches,
    )

    subfolder = st.text_input(
        "Subfolder (optional)",
        placeholder="etl/pipelines",
        help="Leave blank to scan the entire repo",
    )

    scan_btn = st.button(
        "🔍 Scan repository",
        disabled=not (token and repo),
        type="primary",
        use_container_width=True,
    )

    if scan_btn:
        with st.spinner("Fetching files from GitHub…"):
            try:
                loader = st.session_state.loader or GitHubLoader(token=token, repo_name=repo)
                raw_files = loader.get_python_files(branch=branch, subfolder=subfolder)
                st.session_state.files_loaded = len(raw_files)
            except ValueError as e:
                st.error(str(e))
                raw_files = []

        if raw_files:
            with st.spinner(f"Parsing {len(raw_files)} files…"):
                mappings = parse_files(raw_files)
                st.session_state.graph = LineageGraph.from_mappings(mappings)
            st.success(f"Parsed {len(raw_files)} files → {len(mappings)} pipelines found")
        elif not st.session_state.error:
            st.warning("No Python files found in that path.")

    # ---- filters (shown after scan) ----
    graph: LineageGraph | None = st.session_state.graph

    if graph:
        st.divider()
        st.subheader("Filters")

        sel_file = st.selectbox(
            "Pipeline file",
            options=["All"] + graph.all_source_files(),
        )
        sel_table = st.selectbox(
            "Target table",
            options=["All"] + graph.all_target_tables(),
        )
        sel_kind = st.selectbox(
            "Source type",
            options=["All"] + graph.all_source_kinds(),
        )
        hide_dropped = st.toggle("Hide dropped columns", value=False)
        search_term = st.text_input("Search columns", placeholder="e.g. customer_id")

        st.divider()
        stats = graph.summary_stats()
        st.caption(
            f"**{stats['pipeline_files']}** pipelines · "
            f"**{stats['target_tables']}** tables · "
            f"**{stats['total_mappings']}** mappings"
        )
        if stats["warnings"]:
            st.warning(f"{stats['warnings']} parse warnings — see ⚠️ tab")


# ---------------------------------------------------------------------------
# Main area
# ---------------------------------------------------------------------------

graph: LineageGraph | None = st.session_state.graph

if graph is None:
    # Landing state
    st.markdown("## PySpark Lineage Explorer")
    st.markdown(
        "Connect your GitHub repo on the left, hit **Scan repository**, and instantly see "
        "which source columns flow into which Postgres target columns — across every pipeline file."
    )

    col1, col2, col3 = st.columns(3)
    with col1:
        st.info("📄 **Source types**\nCSV · Excel · JSON · Parquet · JDBC · Email")
    with col2:
        st.info("🔍 **Parsed from**\n`.select()` · `.withColumn()` · `.read.*()` · `.write.jdbc()`")
    with col3:
        st.info("🗄️ **Target**\nPostgres tables via `.write.jdbc()` or `.saveAsTable()`")

    st.markdown("---")
    st.caption("All processing is local — your code and token never leave your machine beyond GitHub API calls.")

else:
    # ---- resolve filter values ----
    f_file  = None if sel_file  == "All" else sel_file
    f_table = None if sel_table == "All" else sel_table
    f_kind  = None if sel_kind  == "All" else sel_kind
    f_search = search_term.strip() or None

    stats = graph.summary_stats()

    # ---- summary metrics ----
    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric("Pipeline files",  stats["pipeline_files"])
    m2.metric("Target tables",   stats["target_tables"])
    m3.metric("Column mappings", stats["total_mappings"])
    m4.metric("With transforms", stats["with_transforms"])
    m5.metric("Dropped cols",    stats["dropped_cols"])

    st.divider()

    # ---- tabs ----
    tab_lineage, tab_table, tab_diagram, tab_warnings = st.tabs([
        "📋 Column lineage",
        "🗂️ Full mapping table",
        "🔀 Flow diagram",
        f"⚠️ Warnings ({stats['warnings']})",
    ])

    # ===== TAB 1 — Column lineage (per-file detail) =====
    with tab_lineage:
        if f_file:
            edges = graph.edges_for_file(f_file)
            if not edges:
                st.info("No column mappings found for this file.")
            else:
                target_tables = sorted({e.full_target for e in edges})
                for tbl in target_tables:
                    tbl_edges = [e for e in edges if e.full_target == tbl]
                    st.markdown(f"### → `{tbl}`")
                    left, mid, right = st.columns([5, 1, 5])

                    with left:
                        src_path = tbl_edges[0].source_path or tbl_edges[0].file_name
                        src_icon = tbl_edges[0].source_icon
                        st.markdown(f"**{src_icon} Source:** `{src_path}`")
                        for e in tbl_edges:
                            if e.dropped:
                                st.markdown(
                                    f"<span style='opacity:.4'>~~`{e.source_col}`~~</span> "
                                    "<span style='font-size:11px;color:gray'>dropped</span>",
                                    unsafe_allow_html=True,
                                )
                            else:
                                st.markdown(f"`{e.source_col}`")

                    with mid:
                        st.markdown("<br>" * 2, unsafe_allow_html=True)
                        for e in tbl_edges:
                            if not e.dropped:
                                if e.transform:
                                    st.markdown("⟶")
                                else:
                                    st.markdown("→")
                            else:
                                st.markdown("✕")

                    with right:
                        st.markdown(f"**🗄️ Target:** `{tbl}`")
                        for e in tbl_edges:
                            if e.dropped:
                                st.markdown(
                                    "<span style='opacity:.4;font-size:13px'>—</span>",
                                    unsafe_allow_html=True,
                                )
                            else:
                                suffix = f" `[{e.transform}]`" if e.transform else ""
                                st.markdown(f"`{e.target_col}`{suffix}")

                    st.divider()
        else:
            st.info("Select a specific pipeline file in the sidebar to see column-level detail here.")

            # Show a high-level file → table overview
            st.markdown("#### File → table overview")
            overview_rows = []
            for e in graph.edges:
                overview_rows.append({
                    "Pipeline file": e.file_name,
                    "Source type":   f"{e.source_icon} {e.source_kind}",
                    "Source":        e.source_path or "—",
                    "Target table":  e.full_target,
                })
            if overview_rows:
                df_ov = pd.DataFrame(overview_rows).drop_duplicates()
                st.dataframe(df_ov, use_container_width=True, hide_index=True)

    # ===== TAB 2 — Full flat mapping table =====
    with tab_table:
        df = graph.to_dataframe(
            file_filter=f_file,
            table_filter=f_table,
            kind_filter=f_kind,
            hide_dropped=hide_dropped,
            search=f_search,
        )

        if df.empty:
            st.info("No mappings match the current filters.")
        else:
            st.caption(f"{len(df)} mappings shown")
            st.dataframe(
                df,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "→": st.column_config.TextColumn(width="small"),
                    "Dropped": st.column_config.TextColumn(width="small"),
                    "Transform": st.column_config.TextColumn(width="medium"),
                },
            )

            csv_bytes = df.to_csv(index=False).encode()
            st.download_button(
                "⬇️ Download CSV",
                data=csv_bytes,
                file_name="lineage_mappings.csv",
                mime="text/csv",
            )

    # ===== TAB 3 — Graphviz flow diagram =====
    with tab_diagram:
        dot_str = graph.graphviz_dot(file_filter=f_file)
        try:
            st.graphviz_chart(dot_str, use_container_width=True)
        except Exception as e:
            st.error(f"Could not render diagram: {e}")
            with st.expander("Raw DOT source"):
                st.code(dot_str, language="dot")

    # ===== TAB 4 — Warnings =====
    with tab_warnings:
        if not graph.warnings:
            st.success("No parse warnings.")
        else:
            for fpath, warns in graph.warnings.items():
                with st.expander(f"📄 {fpath} ({len(warns)} warning{'s' if len(warns)>1 else ''})"):
                    for w in warns:
                        st.warning(w)
