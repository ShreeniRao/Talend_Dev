"""
lineage.py
----------
Builds and queries the lineage graph from parsed PipelineMappings.
Provides a clean API for the UI layer — no Spark, no GitHub, no Streamlit here.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
import pandas as pd
from parser import PipelineMapping, ColumnMapping, SourceInfo, TargetInfo


# ---------------------------------------------------------------------------
# Enriched node types for the lineage graph
# ---------------------------------------------------------------------------

SOURCE_ICONS = {
    "csv":     "📄",
    "excel":   "📊",
    "json":    "📋",
    "parquet": "🗜️",
    "jdbc":    "🗄️",
    "email":   "📧",
    "unknown": "❓",
}


@dataclass
class LineageEdge:
    """One source-column → target-column mapping, with all context."""
    file_path: str
    file_name: str

    source_kind: str           # csv / excel / jdbc / …
    source_path: Optional[str]

    source_col: str
    target_col: str
    target_table: str
    target_schema: Optional[str]

    transform: Optional[str]
    dropped: bool

    @property
    def source_icon(self) -> str:
        return SOURCE_ICONS.get(self.source_kind, "❓")

    @property
    def full_target(self) -> str:
        return f"{self.target_schema}.{self.target_table}" if self.target_schema else self.target_table


@dataclass
class LineageGraph:
    """
    The full lineage model built from all parsed pipeline files.
    All query methods return plain Python / pandas objects so the UI
    layer (Streamlit or Dash) never touches PipelineMapping directly.
    """
    edges: list[LineageEdge] = field(default_factory=list)
    warnings: dict[str, list[str]] = field(default_factory=dict)  # file_path -> warnings

    # ---- build ----

    @classmethod
    def from_mappings(cls, mappings: list[PipelineMapping]) -> LineageGraph:
        graph = cls()
        for m in mappings:
            if m.warnings:
                graph.warnings[m.file_path] = m.warnings

            file_name = m.file_path.split("/")[-1]

            # If no targets detected we still want to surface the file as a warning
            if not m.targets:
                if m.sources or m.columns:
                    graph.warnings.setdefault(m.file_path, []).append(
                        "No write target detected — file may be a utility or incomplete pipeline"
                    )
                continue

            for target in m.targets:
                schema, table = _split_table(target.table)

                # Use explicit column mappings if present
                if m.columns:
                    for col in m.columns:
                        src_info = m.sources[0] if m.sources else SourceInfo(kind="unknown")
                        graph.edges.append(LineageEdge(
                            file_path=m.file_path,
                            file_name=file_name,
                            source_kind=src_info.kind,
                            source_path=src_info.path,
                            source_col=col.source_col,
                            target_col=col.target_col,
                            target_table=table,
                            target_schema=schema,
                            transform=col.transform,
                            dropped=col.dropped,
                        ))
                else:
                    # No column-level detail — at least record the file→table link
                    for src in m.sources:
                        graph.edges.append(LineageEdge(
                            file_path=m.file_path,
                            file_name=file_name,
                            source_kind=src.kind,
                            source_path=src.path,
                            source_col="*",
                            target_col="*",
                            target_table=table,
                            target_schema=schema,
                            transform=None,
                            dropped=False,
                        ))

        return graph

    # ---- query API ----

    def all_target_tables(self) -> list[str]:
        """Unique target tables, sorted."""
        seen = []
        for e in self.edges:
            t = e.full_target
            if t not in seen:
                seen.append(t)
        return sorted(seen)

    def all_source_files(self) -> list[str]:
        """Unique pipeline file names, sorted."""
        return sorted({e.file_name for e in self.edges})

    def all_source_kinds(self) -> list[str]:
        return sorted({e.source_kind for e in self.edges})

    def edges_for_file(self, file_name: str) -> list[LineageEdge]:
        return [e for e in self.edges if e.file_name == file_name]

    def edges_for_table(self, table: str) -> list[LineageEdge]:
        return [e for e in self.edges if e.full_target == table or e.target_table == table]

    def to_dataframe(
        self,
        file_filter: Optional[str] = None,
        table_filter: Optional[str] = None,
        kind_filter: Optional[str] = None,
        hide_dropped: bool = False,
        search: Optional[str] = None,
    ) -> pd.DataFrame:
        """
        Full flat mapping table, with optional filters.
        Safe to pass directly to st.dataframe() or dash_table.DataTable().
        """
        edges = self.edges

        if file_filter:
            edges = [e for e in edges if e.file_name == file_filter]
        if table_filter:
            edges = [e for e in edges if e.full_target == table_filter or e.target_table == table_filter]
        if kind_filter:
            edges = [e for e in edges if e.source_kind == kind_filter]
        if hide_dropped:
            edges = [e for e in edges if not e.dropped]
        if search:
            q = search.lower()
            edges = [
                e for e in edges
                if q in e.source_col.lower()
                or q in e.target_col.lower()
                or q in (e.source_path or "").lower()
                or q in e.target_table.lower()
            ]

        rows = []
        for e in edges:
            rows.append({
                "Pipeline file":   e.file_name,
                "Source type":     f"{e.source_icon} {e.source_kind}",
                "Source path/table": e.source_path or "—",
                "Source column":   e.source_col,
                "→":               "→",
                "Target table":    e.full_target,
                "Target column":   e.target_col,
                "Transform":       e.transform or "pass-through",
                "Dropped":         "yes" if e.dropped else "no",
            })

        return pd.DataFrame(rows)

    def summary_stats(self) -> dict:
        active = [e for e in self.edges if not e.dropped]
        return {
            "pipeline_files":  len({e.file_path for e in self.edges}),
            "target_tables":   len(self.all_target_tables()),
            "total_mappings":  len(active),
            "with_transforms": len([e for e in active if e.transform]),
            "dropped_cols":    len([e for e in self.edges if e.dropped]),
            "source_kinds":    self.all_source_kinds(),
            "warnings":        sum(len(v) for v in self.warnings.values()),
        }

    def graphviz_dot(self, file_filter: Optional[str] = None) -> str:
        """
        Generate a Graphviz DOT string for the lineage diagram.
        Each source file is a node; each target table is a node;
        column-level labels on edges.
        Port directly to Dash via `dash_cytoscape` or `graphviz` library.
        """
        edges = self.edges_for_file(file_filter) if file_filter else self.edges
        lines = [
            'digraph lineage {',
            '  rankdir=LR;',
            '  node [shape=box, style=filled, fontname="Helvetica", fontsize=11];',
            '  edge [fontsize=9, fontname="Helvetica"];',
        ]

        # Source nodes (files / db tables)
        src_nodes: set[str] = set()
        for e in edges:
            if not e.dropped:
                node_id = _safe_id(e.file_name)
                if node_id not in src_nodes:
                    src_nodes.add(node_id)
                    label = f"{e.source_icon} {e.file_name}\\n({e.source_kind})"
                    lines.append(f'  {node_id} [label="{label}", fillcolor="#E6F1FB", color="#185FA5"];')

        # Target nodes (postgres tables)
        tgt_nodes: set[str] = set()
        for e in edges:
            if not e.dropped:
                node_id = _safe_id(e.full_target)
                if node_id not in tgt_nodes:
                    tgt_nodes.add(node_id)
                    lines.append(f'  {node_id} [label="🗄 {e.full_target}\\n(postgres)", fillcolor="#EAF3DE", color="#3B6D11"];')

        # Edges
        seen_edges: set[tuple] = set()
        for e in edges:
            if e.dropped:
                continue
            src_id = _safe_id(e.file_name)
            tgt_id = _safe_id(e.full_target)
            edge_key = (src_id, tgt_id, e.source_col, e.target_col)
            if edge_key in seen_edges:
                continue
            seen_edges.add(edge_key)
            if e.source_col == "*":
                label = "(all columns)"
            elif e.source_col == e.target_col:
                label = e.source_col
            else:
                label = f"{e.source_col} → {e.target_col}"
            if e.transform:
                label += f"\\n[{e.transform}]"
            lines.append(f'  {src_id} -> {tgt_id} [label="{label}"];')

        lines.append("}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _split_table(full_name: str) -> tuple[Optional[str], str]:
    """Split 'schema.table' into ('schema', 'table'). No schema → (None, name)."""
    parts = full_name.split(".")
    if len(parts) >= 2:
        return parts[-2], parts[-1]
    return None, full_name


def _safe_id(s: str) -> str:
    """Convert a string to a safe DOT node identifier."""
    return re.sub(r"[^a-zA-Z0-9_]", "_", s)


import re  # noqa: E402  (needed for _safe_id above)
