# PySpark Lineage Explorer

A local GUI tool that reads your PySpark pipeline code from GitHub and produces
an interactive, filterable map of **source column → Postgres target column** lineage.

## Architecture

```
github_loader.py   — GitHub API: fetch .py files from your repo
parser.py          — AST + regex: extract Spark read/write/transform calls
lineage.py         — Data model: build and query the lineage graph
app.py             — Streamlit UI (swap for Dash later — logic unchanged)
```

## Setup

### 1. Install system graphviz (for the flow diagram tab)

**macOS**
```bash
brew install graphviz
```

**Ubuntu/Debian**
```bash
sudo apt-get install graphviz
```

**Windows**
Download from https://graphviz.org/download/

### 2. Install Python dependencies

```bash
pip install -r requirements.txt
```

### 3. Create a GitHub Personal Access Token

1. Go to GitHub → Settings → Developer settings → Personal access tokens → Fine-grained tokens
2. Grant **Contents: Read-only** on the target repo
3. Copy the token (starts with `ghp_`)

### 4. Run the app

```bash
streamlit run app.py
```

The app opens at http://localhost:8501

## Usage

1. Paste your GitHub PAT and repo name (e.g. `myorg/data-pipelines`)
2. Select branch and optional subfolder
3. Click **Scan repository**
4. Use the sidebar filters to drill into specific files, tables, or source types

## What gets parsed

| Pattern | Detected |
|---|---|
| `spark.read.csv("path")` | CSV source |
| `spark.read.format("excel").load("path")` | Excel source |
| `spark.read.json(...)` / `.parquet(...)` | JSON / Parquet source |
| `.option("dbtable", "schema.table")` | JDBC DB source |
| `import imaplib` / `exchangelib` | Email source hint |
| `.withColumn("target", upper(col("src")))` | Column rename + transform |
| `.select(col("src").alias("tgt"))` | Column rename |
| `.select("col1", "col2")` | Pass-through columns |
| `.drop("col")` | Dropped columns |
| `.write.jdbc(url, "schema.table", ...)` | Postgres target |
| `.saveAsTable("schema.table")` | Hive/catalog target |

## Known limitations

- **Dynamic column lists** (e.g. built from Python loops or variables) cannot be
  resolved statically. These are flagged as warnings in the ⚠️ tab.
- **Cross-file transforms** (shared utility functions) are not followed across imports yet.
- Complex chained expressions may only partially parse — the raw expression is
  shown where column names cannot be extracted.

## Porting to Dash

Only `app.py` needs to change. The three logic modules are UI-agnostic.

Replace Streamlit calls with their Dash equivalents:

| Streamlit | Dash |
|---|---|
| `st.sidebar` | `html.Div` in a sidebar layout |
| `st.tabs` | `dcc.Tabs` + `dcc.Tab` |
| `st.dataframe` | `dash_table.DataTable` |
| `st.selectbox` | `dcc.Dropdown` |
| `st.text_input` | `dcc.Input` |
| `st.button` | `html.Button` + `@callback` |
| `st.graphviz_chart` | `dash_cytoscape` or inline SVG |
| `st.metric` | `html.Div` cards |
| `st.session_state` | `dcc.Store` |
